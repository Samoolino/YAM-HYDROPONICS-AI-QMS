# Yam Hydroponics AI QMS
This repository contains the structure for a hydroponics yam tuber farming system integrated with AI/ML QMS and blockchain smart contracts.