# Quality Management Parameters
- Shape
- Moisture
- pH
- Mass
- Growth Time